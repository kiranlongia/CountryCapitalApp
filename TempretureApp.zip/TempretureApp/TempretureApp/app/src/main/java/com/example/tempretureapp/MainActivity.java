package com.example.tempretureapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
// let the user enter a temperatures in celsius or in fahrenhite
// convert from the not empty temperature to the empty one
//if both null show a message says enter the temperature to convert
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
