package com.example.countryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
Button okbutton;
Spinner contryspinnr;
TextView capitalTv,areaTv;
ImageView flag;
String country[]={"Canada","India","Jordan","France","Italy","Japan","Germany"};
String capital[]={"Ottawa","New Delhi","Amman","Paris","Rome","Tokyo","Berlin"};
String area[]={"9.98 million km²","3.287 million km²","89342 million km²","643,801 million km²","301,340 million km²","301,340 million km²","301,340 million km²"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contryspinnr=findViewById(R.id.spCountry);
        okbutton=findViewById(R.id.btnOk);
        capitalTv=findViewById(R.id.tvCapital);
        flag=findViewById(R.id.imageView);
        okbutton.setOnClickListener(this);
        areaTv=findViewById(R.id.tvArea);
        contryspinnr.setOnItemSelectedListener(this);
        //create array adapter and fill it from the array which created as spinner items
        ArrayAdapter aa=new ArrayAdapter(this, android.R.layout.simple_spinner_item,country);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        contryspinnr.setAdapter(aa);
    }

    @Override
    public void onClick(View view) {
        //get the index of the selected item in teh spinner
        int i=contryspinnr.getSelectedItemPosition();
        capitalTv.setText(capital[i]);
        String imgName=country[i].toLowerCase();
        int imgId=getResources().getIdentifier(imgName,"drawable",getPackageName());
        flag.setImageResource(imgId);
        areaTv.setText(area[i]);
    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {

        capitalTv.setText(capital[i]);
        String imgName=country[i].toLowerCase();
        //if names of image files are img0,img1,img2..
        //String imgName="img"+i
        //to assign image file to image view ,u need image id not the name.Through image name , we can get image id

        //to get image id using its name
        int imgId=getResources().getIdentifier(imgName,"drawable",getPackageName());
        //assign the image to the imageview using the image id
        flag.setImageResource(imgId);
        areaTv.setText(area[i]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
