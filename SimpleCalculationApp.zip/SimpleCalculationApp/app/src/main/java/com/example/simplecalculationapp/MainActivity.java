package com.example.simplecalculationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
EditText Firstnum,Secondnum;
Button calc;
TextView result;
RadioButton plus,minus,divide,multiply;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Firstnum=findViewById(R.id.txtFno);
        Secondnum=findViewById(R.id.txtSno);
        result=findViewById(R.id.tvResult);
        plus=findViewById(R.id.rbPlus);
        minus=findViewById(R.id.rbMinus);
        multiply=findViewById(R.id.rbMultiply);
        divide=findViewById(R.id.rbDivide);
        calc=findViewById(R.id.btnCal);

        calc.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        double res=0;
        if (Firstnum.getText().toString().equals("") || Secondnum.getText().toString().equals(""))
            Toast.makeText(getApplicationContext(), "please enter the both values", Toast.LENGTH_LONG).show();
        else {
            double num1 = Double.parseDouble(Firstnum.getText().toString());
            double num2 = Double.parseDouble(Secondnum.getText().toString());
            if(plus.isChecked()){
                res=num1+num2;
            }
            else if(minus.isChecked()){
               res=num1-num2;
            }
            else if(multiply.isChecked()){
                res=num1*num2;
            }
            else if(divide.isChecked()){
                res=num1/num2;

            }
            String r = String.format("%3f",res);
            result.setText(r);
        }
    }
    }

