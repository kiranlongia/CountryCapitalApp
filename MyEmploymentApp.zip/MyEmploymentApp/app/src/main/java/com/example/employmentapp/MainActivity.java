package com.example.employmentapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {
   TextView sal,txtvyr;
    EditText years;
    Button ok;
RadioButton bach,mas,phd,fresh,expert;
RadioGroup radioGroup;
CheckBox eng,fr,sp,hindi,port;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sal=findViewById(R.id.txtSal);
        txtvyr=findViewById(R.id.txtviewYears);
        years=findViewById(R.id.txtYears);
        bach=findViewById(R.id.rbBachelor);
        mas=findViewById(R.id.rbMaster);
        phd=findViewById(R.id.rbPhd);
        fresh=findViewById(R.id.rbFresh);
        expert=findViewById(R.id.rbExp);
        eng=findViewById(R.id.cbEng);
        sp=findViewById(R.id.cbSpanish);
        fr=findViewById(R.id.cbFrench);
        hindi=findViewById(R.id.cbHindi);
        port=findViewById(R.id.cbPort);
        ok=findViewById(R.id.btnOk);
        radioGroup=findViewById(R.id.radioGroup2);

        ok.setOnClickListener(this);
        radioGroup.setOnCheckedChangeListener(this);
    }

    //function to return the basic salary
    public int getSalary() {
      int sal=0;
      if(phd.isChecked())
          sal=65000;
      else if(mas.isChecked())
          sal=58000;
      else
          sal=5000;
      return  sal;
    }
    public  int getLang(){
        int lang=0;
        if(eng.isChecked()){
            if(fr.isChecked())

                lang+=100;
            if(hindi.isChecked())
                lang+=100;
            if(sp.isChecked())
                lang+=100;
            if(port.isChecked())
                lang+=100;
        }
        else
            lang=0;
        return  lang;
    }


    @Override
    public void onClick(View v) {

        double totalSal=0;
        int noYears=0;
        if(expert.isChecked()){
            if(!years.getText().toString().equals(""))
            noYears=Integer.parseInt(years.getText().toString());
            else
                Toast.makeText(getApplicationContext(),"please enter the no of years of experience",Toast.LENGTH_LONG).show();
        }

        totalSal=getSalary()+getLang()+noYears*100;
        totalSal*=12;
        String sa=String.format("%2f",totalSal);
        sal.setText(sa);
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        if(radioGroup.getCheckedRadioButtonId()==R.id.rbExp ){
           txtvyr.setVisibility(View.VISIBLE);
           years.setVisibility(View.VISIBLE);
        }
        else if(radioGroup.getCheckedRadioButtonId()==R.id.rbFresh){
years.setVisibility(View.INVISIBLE);
txtvyr.setVisibility(View.INVISIBLE);
        }

    }
}